package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_16_R2.entity.CraftPlayer;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class ping implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("ping") || label.equalsIgnoreCase("pg")) {
			if(!sender.hasPermission("stat.ping")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /ping(or /pg) <player>");
				return false;
			}
			
			if(!Main.isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			CraftPlayer target = (CraftPlayer) Bukkit.getPlayerExact(args[0]);
			
			sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.GREEN + " has a ping of " + target.getHandle().ping + ", the lower the better");
		}
		
		return false;
	}

}
