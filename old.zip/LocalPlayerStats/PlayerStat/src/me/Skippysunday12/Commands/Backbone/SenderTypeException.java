package me.Skippysunday12.Commands.Backbone;

public class SenderTypeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4409881277090796642L;
	
	public SenderTypeException(String message) {
		super(message);
	}
	
	public SenderTypeException(String message, Throwable t) {
		super(message, t);
	}
	
	

}
