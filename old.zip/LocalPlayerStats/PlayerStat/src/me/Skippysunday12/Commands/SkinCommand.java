package me.Skippysunday12.Commands;

import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.NMS.SkinSetup;
import net.md_5.bungee.api.ChatColor;

public class SkinCommand implements CommandExecutor{

	public static String version = "";
	public static SkinSetup s = new SkinSetup();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(s.successful()) {
			if(label.equalsIgnoreCase("getskin")) {
				
				if(!(sender instanceof Player)) {
					sender.sendMessage("Console cannot run this command!");
					return false;
				}
				
				if(!sender.hasPermission("stat.getskin")) {
					return false;
				}
				
				Player player = (Player) sender;
				
				if(args.length != 1) {
					player.sendMessage(ChatColor.RED + "Incorrect S");
				}
				
				s.skin().spawnSkin(args[0], player);
				
				
			}
			
			else if(label.equalsIgnoreCase("removeskins")) {
				if(!(sender instanceof Player)) {
					sender.sendMessage("Console cannot send this command!");
					return false;
				}
				
				if(!sender.hasPermission("stat.getskin")) return false;
				
				Player player = (Player) sender;
				s.skin().removeSkins(player);
			}
			
			return false;
		}
		
		else {
			Bukkit.getLogger().log(Level.SEVERE, "This command is not compatable with your server version!");
			sender.sendMessage(ChatColor.RED + "This command is not compatable with your server version!");
		}
		return false;
		
		
		
	}
	
	
}
