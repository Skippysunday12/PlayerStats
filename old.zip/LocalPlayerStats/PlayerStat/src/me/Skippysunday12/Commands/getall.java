package me.Skippysunday12.Commands;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class getall implements CommandExecutor, Listener{

	public static HashMap<String, String> name = new HashMap<String, String>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("getall")) {
			if(!(sender instanceof Player)) {
				sender.sendMessage("You cannot run this");
				return false;
			}
			
			Player player = (Player) sender;
			
			if(!player.hasPermission("stat.getall")){
				return false;
			}
			
			if(args.length != 1) {
				player.sendMessage(ChatColor.RED + "Usage: /getall <player>");
				return false;
			}
			
			if(!Main.isOnline(args[0])) {
				player.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			if(name.containsKey(player.getName())) name.remove(player.getName());
			
			name.put(player.getName(), args[0]);
			guimanager.maininv(name.get(player.getName()));
			player.openInventory(guimanager.maininv);

			
		}
		
		return false;
	}
	
	
	
	@EventHandler()
	public static void onClick(InventoryClickEvent event) {
		
		if(!guimanager.inventories.contains(event.getInventory())) return;
		if(event.getCurrentItem() == null) return;
		if(event.getInventory().equals(guimanager.echest) || event.getInventory().equals(guimanager.chest)) {event.setCancelled(true);}
		if(!event.getCurrentItem().getItemMeta().hasLore()) return;
		
		event.setCancelled(true);
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Potion effects")) {
			guimanager.potsinv(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.potinv);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Back")) {
			guimanager.maininv(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.maininv);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Permissions")) {
			guimanager.permInv(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.perminv);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Player Statistics") && !event.getCurrentItem().getItemMeta().getDisplayName().contains("page 2")) {
			guimanager.statsInv1(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.statinv1);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("Player Statistics page 2")) {
			guimanager.statsInv2(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.statinv2);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("See the contents of the inventory a player is currently viewing")) {
			guimanager.chest(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.chest);
			return;
		}
		
		if(event.getCurrentItem().getItemMeta().getDisplayName().contains("See the contents of a players ender chest")) {
			guimanager.eChest(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().openInventory(guimanager.echest);
			return;
		}
		
		if(event.getInventory().equals(guimanager.maininv) && event.getCurrentItem().getType().equals(Material.FILLED_MAP)) {
			Player toT = Bukkit.getPlayerExact(name.get(event.getWhoClicked().getName()));
			event.getWhoClicked().teleport(toT.getLocation());
			event.getWhoClicked().sendMessage(ChatColor.GREEN + "You have been teleported to " + ChatColor.GOLD + toT.getName());
		}
		
		if(event.getCurrentItem().getItemMeta().hasLore() && event.getCurrentItem().getType().equals(Material.ARMOR_STAND)) {
			event.setCancelled(true);
			SkinCommand.s.skin().spawnSkin(name.get(event.getWhoClicked().getName()), (Player) event.getWhoClicked());
			event.getWhoClicked().closeInventory();
		}
		
	}
	
	

}
