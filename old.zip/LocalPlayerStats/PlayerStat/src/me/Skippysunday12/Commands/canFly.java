package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class canFly implements CommandExecutor {

	public boolean isOnline(String arg) {
		if (Main.isOnline(arg)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		if (label.equalsIgnoreCase("canFly")) {
			if (!(sender instanceof Player)) {
				if (args.length == 0) {
					sender.sendMessage(ChatColor.RED + "Usage: /canfly <Player>");
					return false;
				} else if (args.length == 1) {

					if (isOnline(args[0])) {
						Player target = Bukkit.getPlayer(args[0]);
						
						
						

						if (target.getAllowFlight() == true) {
							sender.sendMessage(
									ChatColor.GOLD + args[0] + ChatColor.RESET + "" + ChatColor.RED + " can fly!");
							return false;
						} else {
							sender.sendMessage(
									ChatColor.GOLD + args[0] + ChatColor.RESET + "" + ChatColor.RED + " cannot fly!");
							return false;
						}
					} else {
						sender.sendMessage(ChatColor.GREEN + "That user is not online!");
						return false;
					}

				} else {
					sender.sendMessage(ChatColor.RED + "Usage: /canfly <player>");
					return false;
				}
			}

			Player player = (Player) sender;

			if (player.hasPermission("stat.canfly")) {
				if (args.length == 0) {
					player.sendMessage(ChatColor.RED + "Usage: /canfly <player>");
					return false;
				} else if (args.length == 1) {

					if (isOnline(args[0])) {
						Player target = Bukkit.getPlayer(args[0]);

						if (target.getAllowFlight() == true) {
							player.sendMessage(
									ChatColor.GOLD + args[0] + ChatColor.RESET + "" + ChatColor.RED + " can fly!");
							return false;

						} else {
							player.sendMessage(
									ChatColor.GOLD + args[0] + ChatColor.RESET + "" + ChatColor.RED + " cannot fly!");
							return false;
						}
					} else {
						player.sendMessage(ChatColor.GREEN + "That user is not online!");
						return false;
					}

				} else {
					player.sendMessage(ChatColor.RED + "Usage: /canfly <player>");
					return false;
				}
			}

		}

		return false;
	}

}