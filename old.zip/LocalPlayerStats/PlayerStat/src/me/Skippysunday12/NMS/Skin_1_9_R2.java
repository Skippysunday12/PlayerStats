package me.Skippysunday12.NMS;

import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_9_R2.CraftServer;
import org.bukkit.craftbukkit.v1_9_R2.CraftWorld;
import org.bukkit.craftbukkit.v1_9_R2.entity.CraftPlayer;
import org.bukkit.entity.Player;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import net.md_5.bungee.api.ChatColor;
import net.minecraft.server.v1_9_R2.EntityPlayer;
import net.minecraft.server.v1_9_R2.MinecraftServer;
import net.minecraft.server.v1_9_R2.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_9_R2.PacketPlayOutEntityHeadRotation;
import net.minecraft.server.v1_9_R2.PacketPlayOutNamedEntitySpawn;
import net.minecraft.server.v1_9_R2.PacketPlayOutPlayerInfo;
import net.minecraft.server.v1_9_R2.PlayerConnection;
import net.minecraft.server.v1_9_R2.PlayerInteractManager;
import net.minecraft.server.v1_9_R2.WorldServer;

public class Skin_1_9_R2 implements SkinManager{
	
	public static HashMap<EntityPlayer, Player> skins = new HashMap<EntityPlayer, Player>();

	@Override
	public void spawnSkin(String name, Player pl) {
		Player player = pl;
		Location loc = player.getLocation();
		
		
		String texture = "";
		String signature = "";
		try {
			URL url = new URL("https://api.mojang.com/users/profiles/minecraft/" + name);
			InputStreamReader reader = new InputStreamReader(url.openStream());
			String uuid = new JsonParser().parse(reader).getAsJsonObject().get("id").getAsString();
			
			URL url2 = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid + 
					"?unsigned=false");
			InputStreamReader r = new InputStreamReader(url2.openStream());
			JsonObject property = new JsonParser().parse(r).getAsJsonObject().get("properties").getAsJsonArray().get(0).getAsJsonObject();
			
			texture = property.get("value").getAsString();
			signature = property.get("signature").getAsString();
			
		}catch(Exception e) {
			player.sendMessage(ChatColor.AQUA + "Something went wrong getting the skin! Check the spelling and try again in a minute!");
		}
		
		GameProfile p = new GameProfile(UUID.randomUUID(), name);
		p.getProperties().put("textures", new Property("textures", texture, signature));
		
		MinecraftServer server = ((CraftServer) Bukkit.getServer()).getServer();
		CraftWorld w = (CraftWorld)player.getWorld();
		WorldServer world = w.getHandle();
		
		EntityPlayer npc = new EntityPlayer(server, world, p, new PlayerInteractManager(world));
		npc.setLocation(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
		
		PlayerConnection con = ((CraftPlayer) player).getHandle().playerConnection;
		
		con.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, npc));
		con.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER, npc));
		con.sendPacket(new PacketPlayOutNamedEntitySpawn(npc));
		con.sendPacket(new PacketPlayOutEntityHeadRotation(npc, (byte) (npc.yaw * 256 / 360)));
		con.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER));
		
		skins.put(npc, player);
		
	}

	@Override
	public void removeSkins(Player pl) {
		
		Player player = pl;
		CraftPlayer cp = (CraftPlayer) player;
		for(EntityPlayer n : skins.keySet()) {
			if(skins.get(n) == player) {
				cp.getHandle().playerConnection.sendPacket(new PacketPlayOutEntityDestroy(n.getId()));
			}
		}
		
	}
	
}

