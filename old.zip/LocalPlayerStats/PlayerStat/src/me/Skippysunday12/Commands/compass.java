package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class compass implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("compass") || label.equalsIgnoreCase("cmp")) {
			if(!sender.hasPermission("stat.compass")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /compass <player>");
				return false;
			}
			
			if(!Main.isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[0]);
			
			double locx = target.getCompassTarget().getX();
			double locy = target.getCompassTarget().getY();
			double locz = target.getCompassTarget().getZ();
			
			
			sender.sendMessage(ChatColor.GOLD + args[0] + "'s " + ChatColor.YELLOW + "compass is pointing to ");
			sender.sendMessage(ChatColor.GREEN + "X: " + locx);
			sender.sendMessage(ChatColor.BLUE + "Y: " + locy);
			sender.sendMessage(ChatColor.DARK_PURPLE + "Z: " + locz);
			
			return false;
		}
		
		return false;
	}

}
