package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class customLink implements CommandExecutor{

	private boolean isOnline(String p) {
		return Main.isOnline(p);
	}
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("sendcustomlink") || label.equalsIgnoreCase("scl")) {
			
			if(!sender.hasPermission("stat.link")) {
				return false;
			}
			
			if(args.length != 2) {
				sender.sendMessage(ChatColor.RED + "Usage: /sendcustomlink(or /scl) <link> <player>. Please use this responsibly, and if the link does not start with https:// or http:// then it will not work.");
				return false;
			}
			
			if(!isOnline(args[1])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online!");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[1]);
			
			
			target.sendMessage(ChatColor.GOLD + args[1] + ChatColor.GREEN + " has sent you this custom link: " + ChatColor.AQUA + args[0]);
			
		}
		return false;
	}

}
