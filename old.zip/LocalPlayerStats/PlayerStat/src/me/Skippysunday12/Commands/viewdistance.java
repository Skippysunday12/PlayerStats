package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class viewdistance implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("viewdistance") || label.equalsIgnoreCase("vd")) {
			if(!sender.hasPermission("stat.view")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /viewdistane(or /vd) <player>");
				return false;
			}
			
			if(!Main.isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
			}
			
			Player target = Bukkit.getPlayerExact(args[0]);
			
			sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.GREEN + " can see " + target.getClientViewDistance() + " chunks");
			return false;
		}
		
		return false;
	}

}
