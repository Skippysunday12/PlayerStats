package me.Skippysunday12.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class inventories implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("getInv")) {
			if(!(sender instanceof Player)) {
				sender.sendMessage("You cannot run this command");
				return false;
			}
			
			Player player = (Player) sender;
			
			if(!sender.hasPermission("stat.inv")) {
				return false;
			}
			
			if(args.length != 2) {
				player.sendMessage(ChatColor.RED + "Usage: /getInv <echest/current> <player>");
				return false;
			}
			
			if(!Main.isOnline(args[1])) {
				player.sendMessage(ChatColor.DARK_RED + "That player is not online");
				return false;
			}
			
			if(args[0].equalsIgnoreCase("echest")) {
				guimanager.eChest(args[1]);
				player.openInventory(guimanager.echest);
				return false;
			}
			
			if(args[0].equalsIgnoreCase("current")) {
				try {
					guimanager.chest(args[1]);
					player.openInventory(guimanager.chest);
				}catch (Exception e) {
					player.sendMessage(ChatColor.BLUE + "That player is not currently viewing an inventory");
				}
				return false;
			}
		}
		return false;
	}

}
