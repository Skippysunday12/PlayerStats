package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_16_R2.entity.CraftPlayer;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class uuid implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("uuid")) {
			if(!sender.hasPermission("stat.uuid")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /uuid <player>");
				return false;
			}
			
			if(!Main.isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			CraftPlayer target = (CraftPlayer) Bukkit.getPlayerExact(args[0]);
			
			sender.sendMessage(ChatColor.GOLD + args[0] + "'s " + ChatColor.GREEN + "UUID is: " + target.getUniqueId());
			return false;
		}
		
		return false;
	}

}
