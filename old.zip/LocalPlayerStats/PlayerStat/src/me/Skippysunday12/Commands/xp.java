package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class xp implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("getXp")) {
			
			if(!sender.hasPermission("stat.xp")) {
				return false;
			}
			
			if(args.length != 2) {
				sender.sendMessage(ChatColor.RED + "Usage: /getxp <levels/total> <player>");
				return false;
			}
			
			if(!Main.isOnline(args[1])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[1]);
			
			if(args[0].equalsIgnoreCase("total")) {
				sender.sendMessage(ChatColor.GOLD + args[1] + ChatColor.GREEN + " has a total of " + target.getTotalExperience() + " xp points");
				return false;
			}
			
			else if(args[0].equalsIgnoreCase("levels")) {
				sender.sendMessage(ChatColor.GOLD + args[1] + ChatColor.GREEN + " has " + target.getLevel() + " xp levels");
				return false;
			}
			
			else {
				sender.sendMessage(ChatColor.RED + "Usage: /getxp <levels/total> <player>");
				return false;
			}
		}
		
		return false;
	}

}
