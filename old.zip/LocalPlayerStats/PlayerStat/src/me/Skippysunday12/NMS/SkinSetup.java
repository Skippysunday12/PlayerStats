package me.Skippysunday12.NMS;

import org.bukkit.Bukkit;

public class SkinSetup {
	private String version = "";
	private SkinManager s;
	private boolean success = true;
	
	public SkinSetup() {
		try {
			version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
		} catch(Exception e) {e.printStackTrace();}
		
		if(version.equals("v1_16_R1")) this.s = new Skin_1_16_R1();
		
		else if(version.equals("v1_16_R2")) this.s = new Skin_1_16_R2();
		
		else if(version.equals("v1_16_R3")) this.s = new Skin_1_16_R3();
		
		else if(version.equals("v1_15_R1")) this.s = new Skin_1_15_R1();
		
		else if(version.equals("v1_14_R1")) this.s = new Skin_1_14_R1();
		
		else if(version.equals("v1_13_R2")) this.s = new Skin_1_13_R2();
		
		else if(version.equals("v1_13_R1")) this.s = new Skin_1_13_R1();
		
		else if(version.equals("v1_12_R1")) this.s = new Skin_1_12_R1();
		
		else if(version.equals("v1_11_R1")) this.s = new Skin_1_11_R1();
		
		else if(version.equals("v1_10_R1")) this.s = new Skin_1_10_R1();
		
		else if(version.equals("v1_9_R2")) this.s = new Skin_1_9_R2();
		
		else if(version.equals("v1_9_R1")) this.s = new Skin_1_9_R1();
		
		else if(version.equals("v1_8_R3")) this.s = new Skin_1_8_R3();
		
		else if(version.equals("v1_8_R2")) this.s = new Skin_1_8_R2();
		
		else if(version.equals("v1_8_R1")) this.s = new Skin_1_8_R1();
		
		else success = false;
	}
	
	public SkinManager skin() {
		return s;
	}
	
	public boolean successful() {
		return success;
	}
	
}
