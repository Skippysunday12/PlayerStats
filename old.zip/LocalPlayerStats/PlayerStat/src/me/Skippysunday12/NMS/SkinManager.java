package me.Skippysunday12.NMS;

import org.bukkit.entity.Player;

public interface SkinManager {
	
	public void spawnSkin(String name, Player pl);
	
	public void removeSkins(Player pl);
	
	
}
