package me.Skippysunday12.PlayerStat;

import java.sql.SQLException;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import me.Skippysunday12.Commands.Commands.ArrowsInBody;
import me.Skippysunday12.Commands.Commands.Bed;
import me.Skippysunday12.Commands.Commands.BedCompleter;
import me.Skippysunday12.Commands.Commands.CanFly;
import me.Skippysunday12.Commands.Commands.Compass;
import me.Skippysunday12.Commands.Commands.CustomLink;
import me.Skippysunday12.Commands.Commands.CustomName;
import me.Skippysunday12.Commands.Commands.Damage;
import me.Skippysunday12.Commands.Commands.Get;
import me.Skippysunday12.Commands.Commands.GetAll;
import me.Skippysunday12.Commands.Commands.GetCompleter;
import me.Skippysunday12.Commands.Commands.GetPing;
import me.Skippysunday12.Commands.Commands.GetStat;
import me.Skippysunday12.Commands.Commands.Hand;
import me.Skippysunday12.Commands.Commands.HandCompleter;
import me.Skippysunday12.Commands.Commands.Inventories;
import me.Skippysunday12.Commands.Commands.InventoriesCompleter;
import me.Skippysunday12.Commands.Commands.IsOp;
import me.Skippysunday12.Commands.Commands.Location;
import me.Skippysunday12.Commands.Commands.NameMCLink;
import me.Skippysunday12.Commands.Commands.PotionEffects;
import me.Skippysunday12.Commands.Commands.RenderDistance;
import me.Skippysunday12.Commands.Commands.SkinCommand;
import me.Skippysunday12.Commands.Commands.StatCompleter;
import me.Skippysunday12.Commands.Commands.Surface;
import me.Skippysunday12.Commands.Commands.UUID;
import me.Skippysunday12.Commands.Commands.XP;
import me.Skippysunday12.Commands.Commands.XPCompleter;
import me.Skippysunday12.SQL.BotManager;
import me.Skippysunday12.SQL.SQLSetup;
import me.Skippysunday12.SQL.SQLdata;


public class Main extends JavaPlugin{
	
	public static Main instance;
	public static FileConfiguration config;
	public static boolean sqlSetup;
	private SQLSetup ms;
	
	@Override
	public void onEnable() {
		this.getServer().getPluginManager().registerEvents(new GetAll(), this);
		this.getServer().getPluginManager().registerEvents(new SQLdata(), this);
		
		this.getCommand("canFly").setExecutor(new CanFly());
		this.getCommand("potfects").setExecutor(new PotionEffects());
		this.getCommand("surface").setExecutor(new Surface());
		this.getCommand("where").setExecutor(new Location());
		this.getCommand("get").setExecutor(new Get());
		this.getCommand("get").setTabCompleter(new GetCompleter());
		this.getCommand("stat").setExecutor(new GetStat());
		this.getCommand("stat").setTabCompleter(new StatCompleter());
		this.getCommand("isop").setExecutor(new IsOp());
		this.getCommand("namemcpage").setExecutor(new NameMCLink());
		this.getCommand("sendcustomlink").setExecutor(new CustomLink());
		this.getCommand("bed").setExecutor(new Bed());
		this.getCommand("bed").setTabCompleter(new BedCompleter());
		this.getCommand("compass").setExecutor(new Compass());
		this.getCommand("viewdistance").setExecutor(new RenderDistance());
		this.getCommand("ping").setExecutor(new GetPing());
		this.getCommand("hand").setExecutor(new Hand());
		this.getCommand("hand").setTabCompleter( new HandCompleter());
		this.getCommand("arrowsinbody").setExecutor(new ArrowsInBody());
		this.getCommand("getnick").setExecutor(new CustomName());
		this.getCommand("getxp").setExecutor(new XP());
		this.getCommand("getxp").setTabCompleter(new XPCompleter());
		this.getCommand("lastdamage").setExecutor(new Damage());
		this.getCommand("uuid").setExecutor(new UUID());
		this.getCommand("getall").setExecutor(new GetAll());
		this.getCommand("getInv").setExecutor(new Inventories());
		this.getCommand("getinv").setTabCompleter(new InventoriesCompleter());
		this.getCommand("getskin").setExecutor(new SkinCommand());
		this.getCommand("removeskins").setExecutor(new SkinCommand());
		
		instance = this;
		configurize();
		ms.setUpSql();
		try {
			if(config.getBoolean("discord-settings.enabled") == true)
			BotManager.discordManager();
		} catch (Exception e) {
			Bukkit.getLogger().info("[PlayerStats] Something went wrong while enabling the discord bot!");
		}
		 
        new UpdateChecker(this, 85774).getVersion(version -> {
            if (this.getDescription().getVersion().equalsIgnoreCase(version)) {
                Bukkit.getLogger().info("[PlayerStats] You are up to date!");
            } else {
                Bukkit.getLogger().info("[PlayerStats] There is a new update available!");
            }
        });
		
	}
	
	@Override
	public void onDisable() {
		if(sqlSetup) {
			try {
				ms.close();
			} catch(ClassNotFoundException | SQLException e) {
				Bukkit.getLogger().log(Level.SEVERE, "Something went wrong closing the connection!");
			}
		}
		if(SkinCommand.s.successful())
			for(Player player : Bukkit.getOnlinePlayers()) {
				SkinCommand.s.skin().removeSkins(player);
			}
	}

	private void configurize() {
		saveDefaultConfig();
		config = (YamlConfiguration) this.getConfig();
	}
    

}
