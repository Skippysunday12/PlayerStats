package me.Skippysunday12.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import net.md_5.bungee.api.ChatColor;

public class namemclink implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("namemcpage") || label.equalsIgnoreCase("nmcl")) {
			
			if(!sender.hasPermission("stat.mclink")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /namemcpage(or /nmcl) <player>");
				return false;
			}
			
			sender.sendMessage(ChatColor.BLUE + "https://namemc.com/search?q=" + args[0]);
			
			
		}
		return false;
	}

}
