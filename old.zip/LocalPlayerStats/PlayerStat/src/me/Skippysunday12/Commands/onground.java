package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class onground implements CommandExecutor{
	
	public boolean isOnline(String arg) {
		if (Main.isOnline(arg)) {
			return true;
		}
		return false;
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("surface")) {
			
			if(!sender.hasPermission("stat.surface")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /surface <player>");
				return false;
			}
			
			if(!isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online!");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[0]);
			
			if(target.isFlying()) {
				sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.AQUA + " is currently flying");
				return false;
			}
			
			else if(target.isOnGround()) {
				sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.DARK_GREEN + " is currently on the ground");
				
				if(target.isSprinting()) {
					sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.DARK_GREEN + " is also currently sprinting!");
				}
				return false;
			}
			
			else if(target.isSwimming()) {
				sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.BLUE + "is currenyly swimming");
				return false;
			}
			
			else if(target.getFallDistance() > 0) {
				sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.DARK_BLUE + " is falling");
			}
			
			else {
				sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.WHITE + " is in a place that is currently being worked on. They are either being launched upward, or floating in water."
						+ " Please try again in a minute.");
				return false;
			}
			
			
			
		}
		
		return false;
	}

}
