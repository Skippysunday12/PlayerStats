package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class where implements CommandExecutor{

	private boolean isOnline(String p) {
		return Main.isOnline(p);
	}
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("where")) {
			
			if(!sender.hasPermission("stat.where")) {
				return false;
			}
			
			if(args.length != 1) {
				sender.sendMessage(ChatColor.RED + "Usage: /where <player>");
				return false;
			}
			
			if(!isOnline(args[0])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online!");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[0]);
			
			double locy = target.getLocation().getY();
			double locx = target.getLocation().getX();
			double locz = target.getLocation().getZ();
			
			sender.sendMessage(ChatColor.GOLD + args[0] + ChatColor.WHITE + " is at:");
			sender.sendMessage(ChatColor.GREEN + "X: " + locx);
			sender.sendMessage(ChatColor.BLUE + "Y: " + locy);
			sender.sendMessage(ChatColor.DARK_PURPLE + "Z: " + locz);
			
			
		}
		return false;
	}

}
