package me.Skippysunday12.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import me.Skippysunday12.PlayerStat.Main;
import net.md_5.bungee.api.ChatColor;

public class hand implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if(label.equalsIgnoreCase("hand")) {
			if(!sender.hasPermission("stat.hand")) {
				return false;
			}
			
			if(args.length != 2) {
				sender.sendMessage(ChatColor.RED + "Usage: /hand <main/off> <player>");
				return false;
			}
			
			if(!Main.isOnline(args[1])) {
				sender.sendMessage(ChatColor.DARK_RED + "That user is not online");
				return false;
			}
			
			Player target = Bukkit.getPlayerExact(args[1]);
			
			if(args[0].equalsIgnoreCase("main")) {
				
				String before = "" + target.getInventory().getItemInOffHand();
				String after = before.substring(10);
				String afterafter = "";
				int length = (after.length()-1);
				
				if(after.charAt(length) == '}') {
					afterafter = after.substring(0, ((length)));
				}
				else {
					afterafter = after.substring(0);
				}
				
				sender.sendMessage(ChatColor.GOLD + args[1] + ChatColor.GREEN + " has " + afterafter.toLowerCase() + " in their main hand");
				return false;
			}
			
			else if(args[0].equalsIgnoreCase("off")) {
				
				String before = "" + target.getInventory().getItemInOffHand();
				String after = before.substring(10);
				String afterafter = "";
				int length = (after.length()-1);
				
				if(after.charAt(length) == '}') {
					afterafter = after.substring(0, ((length)));
				}
				else {
					afterafter = after.substring(0);
				}
				
				
				sender.sendMessage(ChatColor.GOLD + args[1] + ChatColor.GREEN + " has " + afterafter.toLowerCase() + " in their offhand");
				return false;
			}
			
			else {
				sender.sendMessage(ChatColor.RED + "Usage: /hand <main/off> <player>");
			}
		}
		return false;
	}

}
